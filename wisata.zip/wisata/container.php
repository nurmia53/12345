<?php 
    include 'root.php';
    $db=new data();

 ?>
<div class="wrapper">
	<div class="semua" style="float:left;">
    	<div class="content">
        <span style="background:#468; display:inherit; padding:10px; color:#fff; font-size:20px">Berita Terbaru & Terkini</span>
        	
            <?php 
                $db->tampil_berita();
             ?>
  
        </div>
    </div>
    <div class="semua" style="float:right; margin-right:6%;">
    	<div class="content">
        <span style="background:#468; display:inherit; padding:10px; color:#fff; font-size:20px">Destinasi Wisata Prioritas</span>
        	<?php 
                $db->tampil_wisata();
             ?>
  
        </div>
    </div>
    <div class="semua" style="float:right; margin-right:6%; ">
    	<div class="content">
        <span style="background:#468; display:inherit; padding:10px; color:#fff; font-size:20px">Info Hotel Terbaru </span>
        	<?php $db->tampil_hotel(); ?>
           
        </div>
    </div>
    <div class="semua" style="float:left">
    	<div class="content">
        <span style="background:#468; display:inherit; padding:10px; color:#fff; font-size:20px">Event Terbaru & Terkini</span>
        	<div class="profil">
            	<img src="asset/image/slider/wayang.jpg" />
                <h1><a href="">Judul Berita 1 yang dimana 1</a></h1>
                <input type="submit" value="19 Agustus 2016" style="background:green"><input type="submit" value="Kategori">
                <p>
                	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                 
                </p>
            </div>
            <div class="profil">
            	<img src="asset/image/slider/wayang.jpg" />
                <h1><a href="">Judul Berita 1 yang dimana 1</a></h1>
                <input type="submit" value="19 Agustus 2016" style="background:green"><input type="submit" value="Kategori">
                <p>
                	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                 
                </p>
            </div>
            <div class="profil">
            	<img src="asset/image/slider/wayang.jpg" />
                <h1><a href="">Judul Berita 1 yang dimana 1</a></h1>
                <input type="submit" value="19 Agustus 2016" style="background:green"><input type="submit" value="Kategori">
                <p>
                	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                 
                </p>
            </div>
  
        </div>
    </div>
    
</div>