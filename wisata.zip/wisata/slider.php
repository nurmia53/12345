<div class="slide-container">

<div class="slideSaya fade">
  <img src="asset/image/slider/banff-lake.jpg" style="width:100%; padding: 0; height:600px; ">
  <div class="text">TEMUKAN DESTINASI WISATA DI NGANJUK</div>
</div>

<div class="slideSaya fade">
  <img src="asset/image/slider/6.jpg" style="width:100%; padding: 0; height:600px; ">
  <div class="text">CARI HOTEL YANG NYAMAN UNTUK LIBURAN ANDA</div>
</div>

<div class="slideSaya fade">
  <img src="asset/image/slider/wayang.jpg" style="width:100%; padding: 0; height:600px; ">
  <div class="text">BERAGAM BUDAYA DI NGANJUK</div>
</div>

<a class="prev" onclick="plusSlides(-1)"><</a>
<a class="next" onclick="plusSlides(1)">></a>

</div>

<script>
var homeSlide = 1;
showSlides(homeSlide);

function plusSlides(n) {
  showSlides(homeSlide += n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("slideSaya");
  if (n > slides.length) {homeSlide = 1}
  if (n < 1) {homeSlide = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  
  slides[homeSlide-1].style.display = "block";
}
</script>