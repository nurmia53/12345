
<div class="header">
	<div class="logo">
    	<a href="index.php"><img src="asset/image/logo.png" width="35" height="35" /></a>
    </div>
    <nav>
    	<ul>
        	<li><a href="" >Galery</a></li>
            <li><a href="" >Event</a></li>
            <li><a href="hotel.php" >Hotel</a></li>
            <li><a href="wisata.php" >Destinasi Wisata</a></li>
            <li><a href="berita.php" >Berita</a></li>
            <li><a href="index.php" >Home</a></li>
        </ul>
    </nav>
</div>