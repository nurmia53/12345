<?php include"../koneksi.php" ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Dashboard | Admint</title>
<style>
*{ margin:0; padding:0; font-family:Arial, Helvetica, sans-serif}
nav{ width:100%; background:#468; position:fixed; z-index:3;}
.kiri{ float:left; width:500px;}.kanan{ float:right}
a{ text-decoration:none}
nav .kanan li{ display:inline; list-style:none}
nav ul li a{ font-size:20px; color:#fff}
nav .kanan li{ display:inline-block; padding:19px;}
nav .kiri li{ display:inline-block; padding:19px;}
a{ text-decoration:none}
.sidebar{ width:20%; height:100%; padding-top:70px; background:#444; overflow:hidden; position:fixed; float:left}
.sidebar ul li{ list-style:none}
.sidebar ul li a{ padding:20px; display:block; width:100%; transition:0.3s ; color:#ccc;}
.sidebar ul li a:hover{ background:#fff; color:#468}
.main{float:right; width:80%; padding:70x}
.isimain{ padding:70px 30px 30px 30px;}
.span{ background:#4689db; display:inherit; padding:7px; font-size:18px; color:#fff;}
input[type=text],select,textarea{margin:10px 0 10px 0; width:400px; padding:10px;}
textarea{ height:200px; }
input[type=submit]{margin:10px 0 10px 0;padding:10px; background:#0C3; overflow:hidden; border:0; outline:0; color:#fff;}



</style>
</head>
<body>
	<nav>
    	<ul class="kiri">
        	<li><a href="" >Dashboard Admin Control </a></li>
        </ul>
        <ul class="kanan">;
        	<li><a href="">Welcome</a></li>
            <div style="clear:both"></div>
        </ul>
    </nav>
    <div class="sidebar">
    	<ul>
        	<li><a href="">Dashboard</a></li>
            <li><a href="">Berita</a></li>
            <li><a href="">Destinasi Wisata</a></li>
            <li><a href="">Data Kategori</a></li>
            <li><a href="">Data Hotel</a></li>
            <li><a href="">Data Event</a></li>
            <li><a href="">Data Tiket</a></li>
            
        </ul>
    </div>
    <div class="main">
    	<div class="isimain">
        	<span class="span">Data Berita</span>
              <style>
              	table{border-collapse:collapse;}
				th, td{ margin:10px 0 10px 10px; padding:7px;}
				img{ width:100px; height:100px;}
              </style>
              <a href="input.php" ><input type="submit" value="Tambah Berita"  /></a>
              <table border="1">
              	<tr>
                	<th>No</th><th>Kategori</th><th>Judul Berita</th><th>Isi Berita</th><th>Tanggal Posting</th><th>Gambar</th>
                </tr>
               <?php 
			   		$data=mysql_query("SELECT * from berita ");
					$no=1;
					

					while($r=mysql_fetch_array($data)){
							$id_kat=$r['kategori'];
							$kat=mysql_query(" select * from kategori where id_kategori='$id_kat'");
							$kat2=mysql_fetch_array($kat);
						?>
                        <tr>
                        	<td><?php echo $no++;?></td>
                            <td><?php echo $kat2['nama_kategori']; ?></td>
                            <td><?php echo $r['judul']; ?></td>
                            <td><?php echo substr($r['isi'],0,50) ?></td>
                            <td><?php echo $r['tanggal']; ?></td>
                            <td><small><img src="../gambar/<?php echo $r['gambar'];?>"</small></td>
                        </tr>
                        <?php
						}
			   ?>
              </table>

        </div>
    	
    </div>

</body>
</html>