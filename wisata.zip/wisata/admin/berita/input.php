<?php include"../koneksi.php" ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Dashboard | Admint</title>
<style>
*{ margin:0; padding:0; font-family:Arial, Helvetica, sans-serif}
nav{ width:100%; background:#468; position:fixed; z-index:3;}
.kiri{ float:left; width:500px;}.kanan{ float:right}
a{ text-decoration:none}
nav .kanan li{ display:inline; list-style:none}
nav ul li a{ font-size:20px; color:#fff}
nav .kanan li{ display:inline-block; padding:19px;}
nav .kiri li{ display:inline-block; padding:19px;}
a{ text-decoration:none}
.sidebar{ width:20%; height:100%; padding-top:70px; background:#444; overflow:hidden; position:fixed; float:left}
.sidebar ul li{ list-style:none}
.sidebar ul li a{ padding:20px; display:block; width:100%; transition:0.3s ; color:#ccc;}
.sidebar ul li a:hover{ background:#fff; color:#468}
.main{float:right; width:80%; padding:70x}
.isimain{ padding:70px 30px 30px 30px;}
.span{ background:#4689db; display:inherit; padding:7px; font-size:18px; color:#fff;}
input[type=text],select,textarea{margin:10px 0 10px 0; width:400px; padding:10px;}
textarea{ height:200px; }
input[type=submit]{margin:10px 0 10px 0;padding:10px; background:#0C3; overflow:hidden; border:0; outline:0; color:#fff;}



</style>
</head>
<body>
	<nav>
    	<ul class="kiri">
        	<li><a href="" >Dashboard Admin Control </a></li>
        </ul>
        <ul class="kanan">;
        	<li><a href="">Welcome</a></li>
            <div style="clear:both"></div>
        </ul>
    </nav>
    <div class="sidebar">
    	<ul>
        	<li><a href="">Dashboard</a></li>
            <li><a href="">Berita</a></li>
            <li><a href="">Destinasi Wisata</a></li>
            <li><a href="">Data Kategori</a></li>
            <li><a href="">Data Hotel</a></li>
            <li><a href="">Data Event</a></li>
            <li><a href="">Data Tiket</a></li>
            
        </ul>
    </div>
    <div class="main">
    	<div class="isimain">
        	<span class="span">Form Input Berita</span>
                            
              <form action="../handler.php?aksi=tambah_berita" method="post" enctype="multipart/form-data">
                    <select name="kategori">
                    <?php 
                        $data=mysql_query(" SELECT * from kategori ORDER BY id_kategori");
                    ?>
                    <?php
                        while(list($k,$n)=mysql_fetch_array($data)){
                            ?>
                            <option value="<?php echo $k?>"><?php echo $n ?></option>
                            <?php
                            }
                    ?>
                    </select><br>
                    <input type="text" name="judul" placeholder="Judul Berita"><br>
                    <textarea name="isi" placeholder="Isi berita...."></textarea><br>
                    <input type="date" name="tanggal" placeholder="Tanggal terbit.."><br>
                    <input type="file" name="gambar"><br>
                    <input type="submit" value="Simpan">
                   </form>

        </div>
    	
    </div>

</body>
</html>