
<?php
include"root.php";
$db= new admin();
$aksi=$_GET['aksi'];
if($aksi=='tambah_kategori'){
	$db->tambah_kategori($_POST['nama_kategori']);
	}
if($aksi=='tambah_berita'){
	$tmp_name=$_FILES['gambar']['tmp_name'];
	$name=$_FILES['gambar']['name'];
	$type=$_FILES['gambar']['type'];
	$loc="gambar/$name";
	move_uploaded_file($tmp_name,$loc) or die(mysql_error());
	$db->tambah_berita($_POST['kategori'],$_POST['judul'],$_POST['isi'],$_POST['tanggal'],$name);
	}
if($aksi=='tambah_wisata'){
	$tmp_name=$_FILES['gambar']['tmp_name'];
	$name=$_FILES['gambar']['name'];
	$type=$_FILES['gambar']['type'];
	$loc="gambar/$name";
	move_uploaded_file($tmp_name,$loc) or die(mysql_error());
	$db->tambah_wisata($_POST['kategori'],$_POST['nama'],$_POST['diskripsi'],$name);
	}
if($aksi=='tambah_tiket'){
	$tmp_name=$_FILES['gambar']['tmp_name'];
	$name=$_FILES['gambar']['name'];
	$type=$_FILES['gambar']['type'];
	$loc="gambar/$name";
	move_uploaded_file($tmp_name,$loc) or die(mysql_error());
	$db->tambah_tiket($_POST['kategori'],$_POST['nama'],$_POST['diskripsi'],$name,$_POST['harga']);
	}
if ($aksi='tambah_hotel') {
	$tmp_name=$_FILES['gambar']['tmp_name'];
	$name=$_FILES['gambar']['name'];
	$type=$_FILES['gambar']['type'];
	$loc="gambar/$name";
	move_uploaded_file($tmp_name, $loc) or die(mysql_error());
	$db->tambah_hotel($_POST['nama'],$_POST['kategori'],$_POST['lokasi'],$_POST['fasilitas'],$_POST['harga'],$name);
}

?>