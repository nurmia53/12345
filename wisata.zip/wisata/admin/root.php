<?php 
	class admin{
		function __construct(){
			mysql_connect("localhost","root","");
			mysql_select_db("dbwisata");
			
			}
		function tambah_kategori($kategori){
			$s=mysql_query("INSERT into kategori SET nama_kategori='$kategori'");
			?>
            <script>
            alert("Data Kategori Berhasil Disimpan");
			window.location.href="kategori/input.php";
            </script>
            <?php
			}	
		function tambah_berita($kategori,$judul,$isi,$tanggal,$gambar){
			$s=mysql_query("INSERT into berita SET kategori='$kategori',judul='$judul',isi='$isi',tanggal='$tanggal',gambar='$gambar'") or die(mysql_error());
			?>
              <script>
            alert("Data Berita Berhasil Disimpan");
			window.location.href="berita/tampil.php";
            </script>
            <?php
			}
		function tambah_wisata($kategori,$nama,$diskripsi,$gambar){
			$s=mysql_query("INSERT into wisata SET kategori='$kategori',nama='$nama',diskripsi='$diskripsi',gambar='$gambar'") or die(mysql_error());
			?>
              <script>
            alert("Data Wisata Berhasil Disimpan");
			window.location.href="berita/input.php";
            </script>
            <?php
			}
		function tambah_tiket($kategori,$nama,$diskripsi,$gambar,$harga){
			$s=mysql_query("INSERT into tiket SET kategori='$kategori',nama='$nama',diskripsi='$diskripsi',gambar='$gambar',harga='$harga'") or die(mysql_error());
			?>
			<script>
            alert("Data Tiket Berhasil Disimpan");
			window.location.href="tiket/input.php";
            </script>
			<?php
			}

		function tambah_hotel($nama,$kategori,$lokasi,$fasilitas,$harga,$gambar){
			$s=mysql_query("INSERT into hotel SET nama='$nama', kategori='$kategori', lokasi='$lokasi', fasilitas='$fasilitas', harga='$harga',gambar='$gambar' ") or die(mysql_error());
			?>
			<script>
            alert("Data Hotel Berhasil Disimpan");
			window.location.href="hotel/input.php";
            </script>
			<?php
		}

		function detail_hotel($id){
			$data=mysql_query("SELECT * from hotel WHERE id_hotel='$id'");
			while ($r=mysql_fetch_array($data)) {
				?>
					
				<?php
			}
		}

	}

		
		
?>