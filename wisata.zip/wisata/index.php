<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="asset/css/style.css">
<link rel="stylesheet" type="text/css" href="asset/css/slide.css"
<link href="asset/css/slide.css"/>
<title>Pusat informasi Wisata</title>
</head>
<?php 
	include"header.php";
?>
<?php 
	include"slider.php";
?>
<div class="dukungan" >
	<center>
    	 <img src="asset/image/dukungan/cafe-512.png"  style=" width:5%;" />
        <img src="asset/image/dukungan/hotel.png"  style=" width:5%;" />
        <img src="asset/image/dukungan/tour.png"  style=" width:5%;" />
    </center>	

</div>
<?php 
	include"container.php";
?>
<body>
</body>
</html>