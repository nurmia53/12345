-- phpMyAdmin SQL Dump
-- version 3.5.2
-- http://www.phpmyadmin.net
--
-- Inang: localhost
-- Waktu pembuatan: 14 Okt 2016 pada 09.54
-- Versi Server: 5.5.25a
-- Versi PHP: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Basis data: `db_lks25`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `name` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `berita`
--

CREATE TABLE IF NOT EXISTS `berita` (
  `id_berita` int(11) NOT NULL AUTO_INCREMENT,
  `kategori` varchar(30) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `isi` text NOT NULL,
  `tanggal` date NOT NULL,
  `gambar` varchar(100) NOT NULL,
  PRIMARY KEY (`id_berita`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data untuk tabel `berita`
--

INSERT INTO `berita` (`id_berita`, `kategori`, `judul`, `isi`, `tanggal`, `gambar`) VALUES
(12, '5', 'Nganjuk Menjadi Kota Adipura tahun 2009', 'Nganjuk Menjdi Kota Bersih Nganjuk Menjdi Kota BersihvNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihvNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota BersihNganjuk Menjdi Kota Bersih', '2016-10-19', '1.png'),
(13, '5', 'Nganjuk Mendapatkan Penghargaan Pesona Nganjuk', 'Nganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona NganjukNganjuk Mendapatkan Penghargaan Pesona Nganjuk', '2016-10-13', '11.jpg'),
(14, '6', 'Air Terjun Singokromo', 'Wisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo KromoWisata baru Air terjun Singo Kromo', '2016-10-19', '8272.jpg'),
(15, '5', 'Pembaruan Taman Alun Alun Nganjuk', 'Pembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun NganjukPembaruan Taman Alun Alun Nganjuk', '2016-10-18', 'pariwisata.png'),
(16, '5', 'HUT Nganjuk Pawai ', 'HUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk PawaiHUT Nganjuk Pawai', '2016-10-13', 'befc.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `hotel`
--

CREATE TABLE IF NOT EXISTS `hotel` (
  `id_hotel` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(200) NOT NULL,
  `kategori` varchar(30) NOT NULL,
  `lokasi` text NOT NULL,
  `fasilitas` text NOT NULL,
  `harga` varchar(30) NOT NULL,
  `gambar` varchar(100) NOT NULL,
  PRIMARY KEY (`id_hotel`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data untuk tabel `hotel`
--

INSERT INTO `hotel` (`id_hotel`, `nama`, `kategori`, `lokasi`, `fasilitas`, `harga`, `gambar`) VALUES
(1, 'Hotel Sinta ', '7', 'Kertosono Nganjuk', 'Fasilitas HotelFasilitas HotelFasilitas HotelFasilitas HotelFasilitas HotelFasilitas Hoteljhwjdhjw jowhdjihweuhduwnaudsugf ufgfaushnjhjksgfjsajghdghsghaghdbwqkjgfgjaHGHEGHJDKAhjkhkjshjkaHDJGHGSHGHJAVSCVASFYKGHGHJGAFGHSGHG', 'Rp.400000', 'hotel.jpg'),
(2, 'Nirwana Hotel & Restaurant', '7', 'Jl. Gatot Subroto No. 2A, Kabupaten Nganjuk, Jawa Timur 64411', 'Fasilitashhjhd djhjhw wjehhjahdkjshfkjsa hdjhaskj dhjashhsg hakhvfs', 'Rp.500000', 'page1-img4.jpg'),
(3, 'Nirwana Hotel & Restaurant', '7', 'Jl. Gatot Subroto No. 2A, Kabupaten Nganjuk, Jawa Timur 64411', 'Fasilitashhjhd djhjhw wjehhjahdkjshfkjsa hdjhaskj dhjashhsg hakhvfs', 'Rp.500000', 'page1-img4.jpg'),
(4, 'Nirwana Hotel & Restaurant', '7', 'Jl. Gatot Subroto No. 2A, Kabupaten Nganjuk, Jawa Timur 64411', 'Fasilitashhjhd djhjhw wjehhjahdkjshfkjsa hdjhaskj dhjashhsg hakhvfs', 'Rp.500000', 'page1-img4.jpg'),
(5, 'Hotel Merdeka', '7', 'Nganjuk', 'FasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitasFasiliitas', 'Rp.89900', '14542829_1793331404269745_231801620_n.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `id_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(30) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(5, 'berita'),
(6, 'wisata'),
(7, 'hotel'),
(8, 'tiket');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tiket`
--

CREATE TABLE IF NOT EXISTS `tiket` (
  `id_tiket` int(11) NOT NULL AUTO_INCREMENT,
  `ketegori` varchar(30) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `diskripsi` text NOT NULL,
  `gambar` varchar(100) NOT NULL,
  `harga` varchar(20) NOT NULL,
  PRIMARY KEY (`id_tiket`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `wisata`
--

CREATE TABLE IF NOT EXISTS `wisata` (
  `id_wisata` int(11) NOT NULL AUTO_INCREMENT,
  `kategori` varchar(30) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `diskripsi` text NOT NULL,
  `gambar` varchar(100) NOT NULL,
  PRIMARY KEY (`id_wisata`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data untuk tabel `wisata`
--

INSERT INTO `wisata` (`id_wisata`, `kategori`, `nama`, `diskripsi`, `gambar`) VALUES
(1, '6', 'ckjkjc', 'kjdkjd', 'hider.jpg'),
(2, '6', 'Air Terjun Sedodo Sawahan Nganjuk', 'dkjkd', '14542829_1793331404269745_231801620_n.jpg'),
(3, '6', 'Air Terjun Sedudo ', 'Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo ', '13.jpg'),
(4, '6', 'Air Terjun Sedudo ', 'Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo Air Terjun Sedudo ', '13.jpg'),
(5, '6', 'Candi Boto di Ngetos', 'Candi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di NgetosCandi Boto di Ngetos', '5.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
