<?php 
class data{

		function __construct(){
			mysql_connect("localhost","root","");
			mysql_select_db("dbwisata");
			
			}
		function tampil_berita(){
			$data=mysql_query("SELECT * from berita ORDER BY id_berita DESC LIMIT 3");

			while ($r=mysql_fetch_array($data)) {
				$id=$r["kategori"];
				$kat=mysql_query("SELECT * from kategori where id_kategori='$id'");
				$kat2=mysql_fetch_array($kat);
				?>
				<div class="profil">
	            	<img src="admin/gambar/<?php echo $r['gambar'];?>">
	                <h1><a href="detail_berita.php?id=<?php echo $r['id_berita'];?>"><?php echo $r['judul']; ?></a></h1>
	                <input type="submit" value="<?php echo $r['tanggal']; ?>" style="background:green"><input type="submit" value="<?php echo $kat2['nama_kategori'];?>">
	                <p>
	                	<?php echo substr($r['isi'],0,100); ?>
	                 
	                </p>
           		 </div>

				<?php
			}
		}

		function tampil_semua_berita(){
			$data=mysql_query("SELECT * from berita ORDER BY id_berita DESC");

			while ($r=mysql_fetch_array($data)) {
				$id=$r["kategori"];
				$kat=mysql_query("SELECT * from kategori where id_kategori='$id'");
				$kat2=mysql_fetch_array($kat);
				?>
				<div class="profil">
	            	<img src="admin/gambar/<?php echo $r['gambar'];?>">
	                <h1><a href="detail_berita.php?id=<?php echo $r['id_berita'];?>"><?php echo $r['judul']; ?></a></h1>
	                <input type="submit" value="<?php echo $r['tanggal']; ?>" style="background:green"><input type="submit" value="<?php echo $kat2['nama_kategori'];?>">
	                <p>
	                	<?php echo substr($r['isi'],0,100); ?>
	                 
	                </p>
           		 </div>

				<?php
			}
		}


		function tampil_wisata(){
			$data=mysql_query("SELECT * from wisata ORDER BY id_wisata DESC LIMIT 3");
			while ($r=mysql_fetch_array($data)) {
				$id=$r['kategori'];
				$kat=mysql_query("SELECT * from kategori where id_kategori='$id'");
				$kat2=mysql_fetch_array($kat);
				?>
				<div class="profil">
	            	<img src="admin/gambar/<?php echo $r['gambar'];?>">
	                <h1><a href="detail_wisata.php?id=<?php echo $r['id_wisata']; ?>"><?php echo $r['nama']; ?></a></h1>
	               <input type="submit" value="<?php echo $kat2['nama_kategori'];?>">
	                <p>
	                 	<?php echo substr($r['diskripsi'],0,100); ?>
	                </p>
            	</div>
				<?php

			}
		}


		function tampil_semua_wisata(){
			$data=mysql_query("SELECT * from wisata ORDER BY id_wisata DESC");
			while ($r=mysql_fetch_array($data)) {
				$id=$r['kategori'];
				$kat=mysql_query("SELECT * from kategori where id_kategori='$id'");
				$kat2=mysql_fetch_array($kat);
				?>
				<div class="profil">
	            	<img src="admin/gambar/<?php echo $r['gambar'];?>">
	                <h1><a href="detail_wisata.php?id=<?php echo $r['id_wisata']; ?>"><?php echo $r['nama']; ?></a></h1>
	               <input type="submit" value="<?php echo $kat2['nama_kategori'];?>">
	                <p>
	                 	<?php echo substr($r['diskripsi'],0,100); ?>
	                </p>
            	</div>
				<?php

			}
		}

		function detail_berita($id){
			$data=mysql_query("SELECT * from berita where id_berita ='$id'");
			while ($r=mysql_fetch_array($data)) {
				?>
					<div class="profil-detail">
						<img src="admin/gambar/<?php echo $r['gambar']; ?>"><br>
						<h1><?php echo $r['judul']; ?></h1>
						<input type="submit" value="<?php echo $r['tanggal']; ?>"><input type="submit" value="<?php echo $r['kategori'];?>" style="background:red"><input type="submit" value="Post | admin" style="background:green">
						<p><?php echo $r['isi']; ?></p>

					</div>

				<?php
			}
		}

		function detail_wisata($id){
			$data=mysql_query("SELECT * from wisata where id_wisata ='$id'");
			while ($r=mysql_fetch_array($data)) {
				?>
					<div class="profil-detail">
						<img src="admin/gambar/<?php echo $r['gambar']; ?>"><br>
						<h1><?php echo $r['nama']; ?></h1>
						<input type="submit" value="<?php echo $r['kategori'];?>" style="background:red"><input type="submit" value="Post | admin" style="background:green">
						<p><?php echo $r['diskripsi']; ?></p>

					</div>

				<?php
			}
		}

	function tampil_hotel(){
		$data=mysql_query(" SELECT * from hotel ORDER BY id_hotel DESC LIMIT 4 ");
		while ($r=mysql_fetch_array($data)) {
			$id=$r['kategori'];
			$kat=mysql_query("SELECT * from kategori where id_kategori='$id'");
			$kat2=mysql_fetch_array($kat);

			?>
				<div class="profil">
            	<img src="admin/gambar/<?php echo $r['gambar']; ?>" /><br>
                <h1><a href="detail_hotel.php?id=<?php echo $r['id_hotel']; ?>"><?php echo $r['nama']; ?></a></h1>
              	<input type="submit" value="<?php echo $kat2['nama_kategori'];?>"><input type="submit" value="Bintang" style="background:yellow;"><input type="submit" value="Lihat Kamar" style="background:#4698db">
             
            	</div>

			<?php
		}
	}

	function detail_hotel($id){
			$data=mysql_query("SELECT * from hotel WHERE id_hotel='$id'");
			while ($r=mysql_fetch_array($data)) {
				$id=$r['kategori'];
				$kat=mysql_query("SELECT * from kategori where id_kategori='$id'");
				$kat2=mysql_fetch_array($kat);
				?>
					<div class="profil-detail">
						<img src="admin/gambar/<?php echo $r['gambar']; ?>"><br>
						<h1><?php echo $r['nama']; ?></h1>
						<input type="submit" value="<?php echo $kat2['nama_kategori'];?>" style="background:red"><input type="submit" value="<?php echo $r['lokasi']; ?>" style="background:green">
						<p><?php echo $r['fasilitas']; ?></p>

					</div>
				<?php
			}
		}

	function tampil_semua_hotel(){
		$data=mysql_query(" SELECT * from hotel ORDER BY id_hotel DESC ");
		while ($r=mysql_fetch_array($data)) {
			$id=$r['kategori'];
			$kat=mysql_query("SELECT * from kategori where id_kategori='$id'");
			$kat2=mysql_fetch_array($kat);

			?>
				<div class="profil">
            	<img src="admin/gambar/<?php echo $r['gambar']; ?>" /><br>
                <h1><a href="detail_hotel.php?id=<?php echo $r['id_hotel']; ?>"><?php echo $r['nama']; ?></a></h1>
              	<input type="submit" value="<?php echo $kat2['nama_kategori'];?>"><input type="submit" value="Bintang" style="background:yellow;"><input type="submit" value="Lihat Kamar" style="background:#4698db">
             
            	</div>

			<?php
		}
	}

	}
?>