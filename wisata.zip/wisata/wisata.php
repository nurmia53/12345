<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="asset/css/style.css">
<link rel="stylesheet" type="text/css" href="asset/css/slide.css"
<link href="asset/css/slide.css"/>
<title>Pusat informasi Wisata</title>
<style type="text/css">
	.wrapper{width: 100%; overflow: hidden; margin: 0; padding: 0;}
		.semua-detail{float: left; margin-top: 60px; margin-left: 6%; width: 555px;}
		.content{}
		.profil-detail{}
		.profil-detail img{width: 100%;  margin-bottom: 10px; height: 400px;}
		.profil-detail h1{font-size: 30px; color: #444; font-family: arial}
		input[type=submit]{margin: 10px  10px 0; padding: 5px; background: #4698db; color: #fff; overflow: hidden; border: 0; outline: 0; border-radius: 10px; margin-bottom: 10px;}
		.profil-detail{color: #444000; font-family: arial }
		.semua-detail-sidebar{float: right; margin-top: 60px; margin-right: 6%; width: 500px;}
		.semua-content-sidebar{}
		.semua-profil-sidebar{width: 100%; margin-bottom: 10px}
		.span{display: inherit; background: #4689db; padding: 7px; color: #fff; font-size: 20px; margin-bottom: 10px;}
		.semua-profil h3{float: right;}
</style>
</head>
<?php 
	include"header.php";
?>

<?php 
	include 'root.php';
	$db=new data()
 ?>
<div class="dukungan">
	<center>
    	
    </center>	

</div>
<div class="semua-detail">
		<div class="content-detail">
			<?php 
                $db->tampil_semua_wisata();
             ?>
		</div>
	</div>

<div class="semua" style="float:right; margin-right:6%;">
    	<div class="content">
        <span style="background:#468; display:inherit; padding:10px; color:#fff; font-size:20px">Last Post</span>
        	<?php 
        		$db->tampil_berita();
        	 ?>
  
        </div>
    </div>
<div class="semua" style="float:right; margin-right:6%;">
    	<div class="content">
        <span style="background:#468; display:inherit; padding:10px; color:#fff; font-size:20px">Info Hotel Terbaru </span>
        	<div class="profil">
            	<img src="asset/image/slider/wayang.jpg" />
                <h1><a href="">Judul Berita 1 yang dimana 1</a></h1>
                <input type="submit" value="19 Agustus 2016" style="background:green"><input type="submit" value="Kategori">
                <p>
                	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                 
                </p>
            </div>
            <div class="profil">
            	<img src="asset/image/slider/wayang.jpg" />
                <h1><a href="">Judul Berita 1 yang dimana 1</a></h1>
                <input type="submit" value="19 Agustus 2016" style="background:green"><input type="submit" value="Kategori">
                <p>
                	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                 
                </p>
            </div>
            <div class="profil">
            	<img src="asset/image/slider/wayang.jpg" />
                <h1><a href="">Judul Berita 1 yang dimana 1</a></h1>
                <input type="submit" value="19 Agustus 2016" style="background:green"><input type="submit" value="Kategori">
                <p>
                	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                 
                </p>
            </div>
  
        </div>
    </div>
<body>
</body>
</html>